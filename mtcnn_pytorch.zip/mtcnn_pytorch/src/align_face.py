from PIL import Image
import cv2
import numpy as np
from skimage import transform as trans

src = np.array([
 [30.2946, 51.6963],
 [65.5318, 51.5014],
 [48.0252, 71.7366],
 [33.5493, 92.3655],
 [62.7299, 92.2041] ], dtype=np.float32 )

# img = Image.open('images/jf.jpg')


# bounding_boxes, landmarks = detect_faces(img)
def align(pil_img, landmarks):
    dst = landmarks[0].astype(np.float32)
    img_cv2 = np.array(pil_img)[...,::-1]
    to_x = src[:,0] * (pil_img.size[0]/96)
    to_y = src[:,1] * (pil_img.size[1]/112)
    facial5points = [[dst[j],dst[j+5]] for j in range(5)]
    tform = trans.SimilarityTransform()
    tform.estimate(np.array(facial5points), np.c_[to_x,to_y])

    M = tform.params[0:2,:]
    warped = cv2.warpAffine(img_cv2,M,(pil_img.size[0], pil_img.size[1]), borderValue = 0.0)
    res = Image.fromarray(warped[...,::-1])
    return res